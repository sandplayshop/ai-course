class CreateCourses < ActiveRecord::Migration[7.1]
  def change
    create_table :courses do |t|
      t.string :title
      t.text :description
      t.decimal :price
      t.integer :point_cost
      t.integer :lesson_point_cost
      t.integer :viewing_period_days

      t.timestamps
    end
  end
end
