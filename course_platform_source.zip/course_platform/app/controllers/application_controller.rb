class ApplicationController < ActionController::Base
  layout 'application'

end
