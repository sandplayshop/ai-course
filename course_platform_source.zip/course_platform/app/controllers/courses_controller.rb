class CoursesController < ApplicationController
  before_action :authenticate_user!, only: [:my_courses]

  def index
    @courses = Course.all
  end

  def show
    @course = Course.find(params[:id])
  end

  def my_courses
    @enrolled_courses = current_user.enrollments.includes(:course).where("expires_at IS NULL OR expires_at > ?", Time.current)
  end
end

