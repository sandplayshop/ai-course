class LessonsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_course
  before_action :set_lesson
  before_action :check_enrollment
  before_action :deduct_points, only: [:show]

  def show
    # 這裡可以添加邏輯來處理影片嵌入
    # 假設 content 包含影片嵌入碼
  end

  private

  def set_course
    @course = Course.find(params[:course_id])
  end

  def set_lesson
    @lesson = @course.lessons.find(params[:id])
  end

  def check_enrollment
    unless current_user.enrolled_courses.include?(@course)
      redirect_to course_path(@course), alert: "您尚未購買此課程，無法觀看單元。"
      return
    end
    
    enrollment = current_user.enrollments.find_by(course: @course)
    if enrollment.expires_at && enrollment.expires_at < Time.current
      redirect_to my_courses_path, alert: "您的課程已過期，無法觀看單元。"
      return
    end
  end

  def deduct_points
    # 這裡我們需要一個 UserLessonView 模型來記錄用戶是否已經為此單元付費
    # 為了不中斷流程，我先假設 UserLessonView 模型已存在，並在下一步創建它
    
    if @course.lesson_point_cost.to_i > 0 && !UserLessonView.exists?(user: current_user, lesson: @lesson)
      if current_user.points >= @course.lesson_point_cost
        current_user.decrement!(:points, @course.lesson_point_cost)
        UserLessonView.create!(user: current_user, lesson: @lesson, deducted_points: @course.lesson_point_cost)
        flash[:notice] = "觀看此單元已扣除 #{@course.lesson_point_cost} 點。"
      else
        redirect_to my_courses_path, alert: "您的點數不足 (#{@course.lesson_point_cost} 點)，無法觀看此單元。請聯繫客服或購買點數。"
      end
    end
  end
end

