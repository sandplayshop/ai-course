module Admin::CoursesHelper
end
