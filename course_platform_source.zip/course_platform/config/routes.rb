Rails.application.routes.draw do
  devise_for :users
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Defines the root path route ("/")
  # root "posts#index"
  namespace :admin do
    root to: "courses#index" # 設定 Admin 命名空間的根路徑為課程列表

    resources :courses do
      resources :lessons
    end
  end
  resource :cart, only: [:show]
  resources :checkouts, only: [:create]
  post 'checkout/ecpay_return', to: 'checkouts#ecpay_return'
  post 'checkout/ecpay_notify', to: 'checkouts#ecpay_notify'
  post 'cart/add/:course_id', to: 'carts#add', as: 'add_to_cart'
  delete 'cart/remove/:course_id', to: 'carts#remove', as: 'remove_from_cart'
  resources :courses, only: [:index, :show] do
    resources :lessons, only: [:show]
  end
  get 'my_courses', to: 'courses#my_courses', as: 'my_courses'
  root to: "home#index"
end
